% A set of testing signals for time domain T.L. simulation
%
% (c) Javier Leonardo Araque Quijano, February 2012
% Universidad Nacional de Colombia
%
% This is educational software that cannot be used outside the course for which it was 
% provided without the author's consent.


function out = mySignal(t)

out = zeros(size(t));

out(t>0 & t<1) = 1; %pulse
%out(t>0 & t<1) = t(t>0 & t<1);%this is a sawtooth
%out(t>0 & t<1) = -cos(t(t>0 & t<1)*2*pi)+1;%cosine pulse
%out(t>0) = sin(t(t>0)*2);