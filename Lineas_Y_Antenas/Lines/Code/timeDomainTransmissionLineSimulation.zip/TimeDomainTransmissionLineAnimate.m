%animate the time-domain behavior of an ideal lossless transmission line
%under a given excitation and termination. You can pause/resume the
%animation by clicking inside the figure. You can halt animation at any
%time by closing the figure.
%
% simply run this script with F5 making sure that mySignal.m is in the
% current folder or in MATLAB's path.
%
% (c) Javier Leonardo Araque Quijano, February 2012
% Universidad Nacional de Colombia
%
% This is educational software that cannot be used outside the course for which it was 
% provided without the author's consent.

% These are parameters that can be configured:
Rg = 10;%output generator resistance
L = 5;%length of transmission line normalized to 1 second light
Zc = 50; % Characteristic impedance of transmission line (must be real)
Rl = 1000; %load resistance (must be real)
nbounces = 10; %how many reflections are to be anImated



nz = 200; %number of samples in z

z = linspace(0,L,nz);

mousedown=0;
myfig=figure('tag','TDTX_anim');
set(myfig,'windowbuttondownfcn','mousedown=1;',...
    'windowbuttonupfcn','mouseup=1;');


vp = zeros(1,nz); %forward signal
vm = zeros(1,nz); %backward signal

gammaL = (Rl-Zc)/(Rl+Zc);
gammaS = (Rg-Zc)/(Rg+Zc);

for t = linspace(0,nz*nbounces,nz^2*nbounces/L) %<= (nz*nbounces) && t>=0 
    
    %signal at v = 0
    v0 = Zc/(Zc+Rg)*mySignal(t) + vm(2)*gammaS; %plus reflection of backward wave

    vp = [v0,vp(1:(end-1))];

    %signal at v=L
    vL = vp(end) * gammaL;    

    vm = [vm(2:end),vL];
    
    if mousedown %check for another mouse click
        mousedown = 0;
        %wait till click is done again, check also figure closing
        while ~mousedown && ~isempty(findobj('tag','TDTX_anim'))
            drawnow;
        end
        
        mousedown = 0;
    end
    
    if isempty(findobj('tag','TDTX_anim')),break;end    
    
    hold off;
    plot(z,vp+2,'b');hold on
    plot(z,vm-2,'r');
    plot(z,vm+vp,'color',[1 0 1],'linewidth',3);
    axis([0 L -3 5]);
    text(L/2,2.5,'Forward');
    text(L/2,0.5,'Total');
    text(L/2,-1.5,'Backward');
    drawnow
end