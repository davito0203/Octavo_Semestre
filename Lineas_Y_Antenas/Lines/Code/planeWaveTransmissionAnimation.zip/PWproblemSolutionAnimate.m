%solution and animation of the problem of a plane wave incident on an
%infinite interface. For clarity this does not include the reflected wave,
%only incident and transmitted.
%
%Simply run this script with F5, first the frames are
%computed, finally the animation is presented.
%
% (c) Javier Leonardo Araque Quijano, February 2012
% Universidad Nacional de Colombia
%
% This is educational software that cannot be used outside the course for which it was 
% provided without the author's consent.


thetai = 20*pi/180; %incidence angle
epsilonr = 3-0.2*j; %

sinThetaI = sin(thetai);
cosThetaI = cos(thetai);

k1 = 2*pi*[cosThetaI,-sinThetaI];%x<0

%Snell law
sinThetaT = sin(thetai)/sqrt(epsilonr);
cosThetaT = sqrt(1-sinThetaT^2);

Et = 2*cosThetaI/sqrt(epsilonr)/(cosThetaI/sqrt(epsilonr)+cosThetaT);

k2 = 2*pi*sqrt(epsilonr)*[cosThetaT,-sinThetaT];

axlims = [-5 10 -5 5];pixdim = 0.03;

[xx,yy] = ndgrid(linspace(axlims(1),axlims(2),round(diff(axlims(1:2))/pixdim)),...
    linspace(axlims(3),axlims(4),round(diff(axlims(1:2))/pixdim)));

%fields at t = 0
negx = xx<=0;
posx = xx>=0;
E = zeros(size(xx));

nsteps = 20;
ncycles = 1;

figure('tag','PWanim');

clear M;

for contc = 1:ncycles
    for cont=1:nsteps
        
        if isempty(findobj('tag','PWanim'))
            break
        end
        
        ang = (cont-1)*2*pi/nsteps;
        
        E(negx) = real(exp(-j*(k1(1)*xx(negx)+k1(2)*yy(negx))+j*ang));
        E(posx) = real(exp(-j*(k2(1)*xx(posx)+k2(2)*yy(posx))+j*ang));
        
        hold off
        pcolor(xx,yy,E);
        hold on
        plot3([0 0 0 0 0],axlims([3 4 4 3 3]),[1 1 -1 -1 1],'k--','linewidth',4);
        shading flat
        colorbar
        axis image
        view([0 90])
        drawnow
        
        if contc == 1 %capture movie
            M(cont) = getframe(gcf);
        end
    end
    if isempty(findobj('tag','PWanim'))
        break
    end
end

leofigure('PWanim');
movie(M,10);

%% now do a 3-D surf plot
hold off
surf(xx,yy,E);
hold on
plot3([0 0 0 0 0],axlims([3 4 4 3 3]),[1 1 -1 -1 1],'k--','linewidth',4);
%leocolor
shading interp
axis image
view([0 90])
drawnow
